import re
import string
from sys import float_repr_style
from typing import ForwardRef


def printsomething():
    print("Hello from python!")

def PrintMe(v):
    print("You sent me: " + v)
    return 100;

def SquareValue(v):
    return v * v

def printMenu():
    print("Welcome - Please enter an option below.\n")
    print("1. Print frequency of all items purchased.")
    print("2. Print frequency of a specific item purchased.")
    print("3. Print a histogram of all items purchased in the given day.")
    print("4. Exit.\n")
    
#This outputs the frequency of all items
def allFrequency():
    f = open("CS210_Project_Three_Input_File.txt", "r")
    freqDict = {}
    #Create dictionary and iterate through it to output frequency
    for x in f:
        currentWord = f.readline()
        currentWord = re.sub("\n", '', currentWord)
        if currentWord in freqDict:
            freqDict[currentWord] = freqDict[currentWord] + 1
        else:
            freqDict[currentWord] = 1
    for i in freqDict:
        print(i, freqDict[i])
    print("\n\n")
    f.close()

#This function finds frequency of a specific item
def findItem(v):
    #Open the input file
    f = open("CS210_Project_Three_Input_File.txt", "r")
    freqDict = {}
    #This reads line by line and replaces newlines
    for x in f:
        currentWord = f.readline()
        currentWord = re.sub("\n", '', currentWord)
        #Adds line to dictionary
        if currentWord in freqDict:
            freqDict[currentWord] = freqDict[currentWord] + 1
        else:
            freqDict[currentWord] = 1
    #Outputs our information
    if v in freqDict:
        print("\nThere were", freqDict[v], "purchases of", v, "today.\n")
    else:
        print("Sorry, I can't find", v)
    #close file that we opened earlier
    f.close()
    return 0

#This function creates the DAT file
def createDAT():
    #Open our starting data
    f = open("CS210_Project_Three_Input_File.txt", "r")
    freqDict = {}
    #Create dictionary from starting data
    for x in f:
        currentWord = f.readline()
        currentWord = re.sub("\n", '', currentWord)
        if currentWord in freqDict:
            freqDict[currentWord] = freqDict[currentWord] + 1
        else:
            freqDict[currentWord] = 1
    n = open("frequency.dat", "w")
    #Create the output file and output it
    for i in freqDict:
        n.write(i)
        n.write(" ")
        n.write(str(freqDict[i]))
        n.write("\n")
    n.close()
    
    
